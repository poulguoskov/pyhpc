#!/bin/bash
#BSUB -J haversine
#BSUB -q hpc
#BSUB -W 2
#BSUB -n 1
#BSUB -R "rusage[mem=4GB]"
#BSUB -R "select[model == XeonGold6126]"
#BSUB -o batch_output/%J.out
#BSUB -e batch_output/%J.err

source /dtu/projects/02613_2025/conda/conda_init.sh
conda activate 02613

python points.py input.csv